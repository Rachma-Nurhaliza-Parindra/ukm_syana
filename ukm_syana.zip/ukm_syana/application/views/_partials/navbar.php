<nav class="navbar">
	<a href="<?= site_url() ?>">Home</a>
	<a href="<?= site_url('ukm') ?>">Anggota</a>
	<a href="<?= site_url('dokumen') ?>">Dokumentasi</a>
	<a href="<?= site_url('page/about') ?>">About</a>
	<a href="<?= site_url('page/contact') ?>">Contact</a>
	<a href="<?= site_url('search') ?>">Search</a>
	<a href="<?= site_url('auth/login') ?>" style="margin-left:auto">Login</a>
</nav>