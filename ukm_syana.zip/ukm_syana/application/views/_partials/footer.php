<footer class="footer">
	&copy; <?= Date('Y') ?> Syandana Nawasena
</footer>