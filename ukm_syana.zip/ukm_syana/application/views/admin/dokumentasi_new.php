<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <main class="main">
        <?php $this->load->view('admin/_partials/side_nav.php') ?>

        <div class="content">
            <h1>Tambah Dokumentasi Baru</h1>

            <form action="<?= site_url('admin/dokumentasi/new/') ?>" method="POST" enctype="multipart/form-data">
                <div>
                    <label for="nama_kegiatan">Nama Kegiatan</label>
                    <input type="text" name="nama_kegiatan" class="<?= form_error('nama_kegiatan') ? 'invalid' : '' ?>" placeholder="Nama Kegiatan" value="<?= set_value('nama_kegiatan') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('nama_kegiatan') ?>
                    </div>
                </div>

                <div>
                    <label for="tanggal">Tanggal</label>
                    <input type="date" name="tanggal" class="<?= form_error('tanggal') ? 'invalid' : '' ?>" value="<?= set_value('tanggal') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('tanggal') ?>
                    </div>
                </div>

                <!-- <div>
                    <label for="gambar">Gambar</label>
                    <input type="file" name="gambar" class="<?= form_error('gambar') ? 'invalid' : '' ?>" placeholder="Gambar" value="<?= set_value('gambar') ?> "/>
                    <div class="invalid-feedback">
                        <?= form_error('gambar') ?>
                    </div>
                </div> -->

                <div>
                    <label for="deskripsi">Deskripsi</label>
                    <input type="text" name="deskripsi" class="<?= form_error('content') ? 'invalid' : '' ?>" placeholder="Deskripsi" value="<?= set_value('content') ?> "/>
                    <div class="invalid-feedback">
                        <?= form_error('content') ?>
                    </div>
                </div>

                <div>
                    <button type="submit" class="button button-primary">Submit</button>
                </div>

            </form>

            <?php $this->load->view('admin/_partials/footer.php') ?>
        </div>
    </main>
</body>

</html>
