<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <main class="main">
        <?php $this->load->view('admin/_partials/side_nav.php') ?>

        <div class="content">
            <h1>Edit Dokumentasi</h1>

            <form action="" method="POST">
            <!-- <form action="<?= site_url('admin/dokumentasi/edit/'.$dokumentasi->id_dokumentasi) ?>" method="POST" enctype="multipart/form-data"> -->
                <div>
                    <label for="nama_kegiatan">Nama Kegiatan</label>
                    <input type="text" name="nama_kegiatan" class="<?= form_error('nama_kegiatan') ? 'invalid' : '' ?>" placeholder="Nama Kegiatan" value="<?= $dokumentasi->nama_kegiatan ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('nama_kegiatan') ?>
                    </div>
                </div>

                <div>
                    <label for="tanggal">Tanggal</label>
                    <input type="date" name="tanggal" class="<?= form_error('tanggal') ? 'invalid' : '' ?>" value="<?= $dokumentasi->tanggal ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('tanggal') ?>
                    </div>
                </div>

                <!-- <div>
                    <label for="gambar">Gambar</label>
                    <img src="<?= base_url('path_to_your_image_display.php?id='.$dokumentasi->id_dokumentasi) ?>" alt="Preview" style="max-width: 100px; max-height: 100px;">
                    <input type="file" name="gambar" class="<?= form_error('gambar') ? 'invalid' : '' ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('gambar') ?> 
                    </div>
                </div> -->

                <div>
                <label for="content">Deskripsi</label>
                <textarea name="content" cols="30" rows="10" placeholder="Tuliskan deskripsi anda"><?= form_error('content') ? set_value('content') : $dokumentasi->content ?></textarea>
            </div>

                <div>
                    <button type="submit" class="button button-primary">Submit</button>
                </div>
            </form>

            <?php $this->load->view('admin/_partials/footer.php') ?>
        </div>
    </main>
</body>

</html>
