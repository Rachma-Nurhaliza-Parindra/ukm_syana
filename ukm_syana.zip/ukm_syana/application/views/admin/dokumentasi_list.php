<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
	<main class="main">
		<?php $this->load->view('admin/_partials/side_nav.php') ?>

		<div class="content">
			<h1>List Dokumentasi</h1>

			<div class="toolbar">
				<a href="<?= site_url('admin/dokumentasi/new/') ?>" class="button button-primary" role="button">+ Tulis Dokumentasi</a>
			</div>
            <div style="display: flex; justify-content: flex-start;">
            <form action="" method="GET" style="flex-direction: row; width:360px; display: flex; justify-content: flex-start;">
            <input type="search" name="keyword" placeholder="Cari dokumentasi" value="<?= html_escape($keyword) ?>" style="margin-right: auto;">
            <input type="submit" value="Cari" class="button" style="width: 32%;">
            </form>
            </div>

			<table class="table">
				<thead>
					<tr>
						<th style="width: 10%;" class="text-center">Nama Kegiatan</th>
                        <th style="width: 15%;" class="text-center">Tanggal</th>
						<th style="width: 15%;" class="text-center">Deskripsi</th>
						<th style="width: 20%;" class="text-center">Action</th>
					</tr>
				</thead>
<tbody>
    <?php foreach($ukmm as $dokumentasi): ?>
        <tr>
            <td>
                <div><?= $dokumentasi->nama_kegiatan ?></div>
            </td>
            <td>
                <div><?= $dokumentasi->tanggal ?></div>
            </td>
            <td>
                <div><?= $dokumentasi->content ?></div>
            </td>
            <td>
                <div class="action">
                    <a href="<?= site_url('admin/dokumentasi/edit/'.$dokumentasi->id_dokumentasi) ?>" class="button button-small" role="button">Edit</a>
                    <a href="#" 
                        data-delete-url="<?= site_url('admin/dokumentasi/delete/'.$dokumentasi->id_dokumentasi) ?>" 
                        class="button button-small button-danger" 
                        role="button"
                        onclick="deleteConfirm(this)">Delete</a>
                </div>
            </td>
        </tr>
    <?php endforeach ?>
</tbody>
			</table>

			<?php $this->load->view('admin/_partials/footer.php') ?>
		</div>
	</main>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function deleteConfirm(event){
        Swal.fire({
            title: 'Delete Confirmation!',
            text: 'Are you sure to delete the item?',
            icon: 'warning',
            showCancelButton: true,
            cancelButtonText: 'No',
            confirmButtonText: 'Yes, Delete',
            confirmButtonColor: 'red'
        }).then(dialog => {
            if(dialog.isConfirmed){
                window.location.assign(event.dataset.deleteUrl);
            }
        });
    }
</script>

<?php if($this->session->flashdata('message')): ?>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: 'success',
            title: '<?= $this->session->flashdata('message') ?>'
        })
    </script>
<?php endif ?>

</body>

</html>

<!-- <!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <main class="main">
        <?php $this->load->view('admin/_partials/side_nav.php') ?>

        <div class="content">
            <h1>List Dokumentasi</h1>

            <div class="toolbar">
                <a href="<?= site_url('admin/dokumentasi/new/') ?>" class="button button-primary" role="button">+ Tambah Dokumentasi</a>
            </div>

            <table class="table">
                <thead>
                    <tr>
                        <th>Nama Kegiatan</th>
                        <th style="width: 15%;" class="text-center">Tanggal</th>
                        <th style="width: 15%;" class="text-center">Gambar</th>
                        <th style="width: 25%;" class="text-center">Deskripsi</th>
                        <th style="width: 25%;" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($dokumenn as $dokumentasi): ?>
                        <tr>
                            <td>
                                <div><?= $dokumentasi->nama_kegiatan ?></div>
                            </td>
                            <td class="text-center">
                                <div><?= $dokumentasi->tanggal ?></div>
                            </td>
                            <td class="text-center">
                                <div>
                                    <?php if ($dokumentasi->gambar): ?>
                                        <?php
                                        // Mendapatkan tipe gambar dari data mediumblob
                                        $imageFormat = 'png'; // Setel default jika tidak ada tipe gambar
                                        $allowedFormats = ['jpg', 'jpeg', 'png', 'gif']; // Tipe gambar yang diperbolehkan
                                        
                                        // Mendapatkan informasi tipe gambar dari data mediumblob
                                        $imageData = $dokumentasi->gambar;
                                        $imageDataInfo = getimagesizefromstring($imageData);
                                        if ($imageDataInfo !== false && isset($imageDataInfo['mime'])) {
                                            $mime = $imageDataInfo['mime'];
                                            $mimeParts = explode('/', $mime);
                                            if (count($mimeParts) === 2 && in_array($mimeParts[1], $allowedFormats)) {
                                                $imageFormat = $mimeParts[1];
                                            }
                                        }
                                        
                                        // Konversi data gambar menjadi base64
                                        $imageDataEncoded = base64_encode($imageData);
                                        $src = 'data:image/' . $imageFormat . ';base64,' . $imageDataEncoded; // Membuat URL gambar dari base64 data
                                        ?>
                                        <img src="<?= $src ?>" alt="Preview" style="max-width: 100px; max-height: 100px;">
                                    <?php else: ?>
                                        <span>No Image</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div><?= $dokumentasi->content ?></div>
                            </td>
                            <td class="text-center">
                                <div class="action">
                                    <a href="<?= site_url('admin/dokumentasi/edit/' . $dokumentasi->id_dokumentasi) ?>" class="button button-small" role="button">Edit</a>
                                    <a href="#" 
                                        data-delete-url="<?= site_url('admin/dokumentasi/delete/' . $dokumentasi->id_dokumentasi) ?>" 
                                        class="button button-small button-danger" 
                                        role="button"
                                        onclick="deleteConfirm(this)">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>

            <?php $this->load->view('admin/_partials/footer.php') ?>
        </div>
    </main>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function deleteConfirm(event){
            Swal.fire({
                title: 'Delete Confirmation!',
                text: 'Are you sure to delete the item?',
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'No',
                confirmButtonText: 'Yes, Delete',
                confirmButtonColor: 'red'
            }).then(dialog => {
                if(dialog.isConfirmed){
                    window.location.assign(event.dataset.deleteUrl);
                }
            });
        }
    </script>

    <?php if($this->session->flashdata('message')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'success',
                title: '<?= $this->session->flashdata('message') ?>'
            })
        </script>
    <?php endif ?>
</body>

</html> -->
