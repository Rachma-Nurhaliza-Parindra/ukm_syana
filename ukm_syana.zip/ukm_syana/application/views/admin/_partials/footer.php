<footer class="footer">
	&copy; <?= Date('Y') ?> Syandana Nawasena Version 1.0.0
</footer>