<aside class="side-nav">
	<div class="brand">
		<h2>Syandana Nawasena</h2>
	</div>
	<nav>
		<a href="<?= site_url('admin/dashboard') ?>">Overview</a>
		<a href="<?= site_url('admin/post') ?>">Data Anggota</a>
		<a href="<?= site_url('admin/kas') ?>">Data Uang Kas</a>
		<a href="<?= site_url('admin/dokumentasi') ?>">Data Dokumentasi</a>
		<a href="<?= site_url('admin/feedback') ?>">Feedback</a>
		<a href="<?= site_url('auth/logout') ?>">Logout</a>
	</nav>
</aside>