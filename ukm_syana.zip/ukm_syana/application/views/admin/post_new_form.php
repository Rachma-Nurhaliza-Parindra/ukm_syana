<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <main class="main">
        <?php $this->load->view('admin/_partials/side_nav.php') ?>

        <div class="content">
            <h1>Tulis Nama Anggota</h1>

            <form action="<?= site_url('admin/post/new') ?>" method="POST">
                <div>
                    <label for="title">Nama Anggota</label>
                    <input type="text" name="title" class="<?= form_error('title') ? 'invalid' : '' ?>" placeholder="Nama Anggota" value="<?= set_value('title') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('title') ?>
                    </div>
                </div>

                <!-- <div>
                    <label for="id_user">Id User</label>
                    <select name="id_user" class="<?= form_error('id_user') ? 'invalid' : '' ?>">
                        <option value="id_user" <?= set_select('id_user', '') ?>></option>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_user') ?>
                    </div>
                </div>

                <div>
                    <label for="id_user">Id User</label>
                    <select name="id_user" class="<?= form_error('id_user') ? 'invalid' : '' ?>">
                        <option value="">Pilih User</option>
                        <?php foreach ($list_id_users as $user) : ?>
                            <option value="<?= $user->id_user ?>"><?= $user->id_user ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_user') ?>
                    </div>
                </div>

                <div>
                    <label for="id_user">Id User</label>
                    <select name="id_user" class="<?= form_error('id_user') ? 'invalid' : '' ?>">
                        <?php if ($list_id_users) : ?>
                            <?php foreach ($list_id_users as $user) : ?>
                                <option value="<?= $user->id_user ?>"><?= $user->name ?></option>
                            <?php endforeach ?>
                        <?php else : ?>
                            <option value="">No users found</option>
                        <?php endif ?>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_user') ?>
                    </div>
                </div> -->

                <div>
                    <label for="divisi">Divisi</label>
                    <input type="text" name="divisi" class="<?= form_error('divisi') ? 'invalid' : '' ?>" placeholder="Divisi" value="<?= set_value('divisi') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('divisi') ?>
                    </div>
                </div>

                <div>
                    <label for="jabatan">Jabatan</label>
                    <input type="text" name="jabatan" class="<?= form_error('jabatan') ? 'invalid' : '' ?>" placeholder="Jabatan" value="<?= set_value('jabatan') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('jabatan') ?>
                    </div>
                </div>

                <div>
                    <label for="content">Deskripsi</label>
                    <textarea name="content" cols="30" rows="10" placeholder="Tuliskan Data Lengkap kamu"><?= set_value('content') ?></textarea>
                </div>

                <div>
                    <button type="submit" class="button button-primary">Submit</button>
                </div>

            </form>

            <?php $this->load->view('admin/_partials/footer.php') ?>
        </div>
    </main>
</body>

</html>
