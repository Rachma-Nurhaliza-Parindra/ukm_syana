<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <main class="main">
        <?php $this->load->view('admin/_partials/side_nav.php') ?>

        <div class="content">
            <h1>Tulis Uang Kas</h1>

            <form action="<?= site_url('admin/kas/new/') ?>" method="POST"> 

                <!-- <div>
                    <label for="id_anggota">Id Anggota</label>
                    <select name="id_anggota" class="<?= form_error('id_anggota') ? 'invalid' : '' ?>">
                        <option value="id_anggota">Pilih Anggota</option>
                        <?php foreach ($list_id_anggota as $anggota) : ?>
                            <option value="<?= $anggota->id_anggota ?>"><?= $anggota->title ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_anggota') ?>
                    </div>
                </div>
                <div>
                    <label for="id_anggota">Anggota</label>
                    <select name="id_anggota" class="<?= form_error('id_anggota') ? 'invalid' : '' ?>">
                        <option value="">Pilih Anggota</option>
                        <?php foreach ($anggota_list as $anggota) : ?>
                            <option value="<?= $anggota['id_anggota'] ?>" <?= set_select('id_anggota', $anggota['id_anggota']) ?>>
                                <?= $anggota['title'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_anggota') ?>
                    </div>
                </div> -->

                <div>
                    <label for="status">Status</label>
                    <select name="status" class="<?= form_error('status') ? 'invalid' : '' ?>">
                        <option value="masuk" <?= set_select('status', 'masuk') ?>>Masuk</option>
                        <option value="keluar" <?= set_select('status', 'keluar') ?>>Keluar</option>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('status') ?>
                    </div>
                </div>

                <div>
                    <label for="tanggal">Tanggal</label>
                    <input type="date" name="tanggal" class="<?= form_error('tanggal') ? 'invalid' : '' ?>" value="<?= set_value('tanggal') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('tanggal') ?>
                    </div>
                </div>

                <div>
                <label for="id_dokumentasi">Nama Kegiatan</label>
                <select name="id_dokumentasi" class="form-control">
                    <option value="">--Pilih Kegiatan--</option>
                    <?php foreach ($dokumentasi as $dokumen) {?>
                        <option value="<?= $dokumen->id_dokumentasi ?>">
                            <?= $dokumen->nama_kegiatan ?>
                        </option>
                    <?php } ?>
                </select>
                </div>

                <!-- <div>
                    <label for="id_dokumentasi">Nama Kegiatan</label>
                    <select name="id_dokumentasi" class="<?= form_error('id_dokumentasi') ? 'invalid' : '' ?>">
                        <?php if (!empty($list_id_dokumentasi)) : ?>
                            <?php foreach ($list_id_dokumentasi as $dokumentasi) : ?>
                                <option value="<?= $dokumentasi->id_dokumentasi ?>"><?= $dokumentasi->nama_kegiatan ?></option>
                            <?php endforeach ?>
                        <?php else : ?>
                            <option value="">Data tidak ditemukan</option>
                        <?php endif ?>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_dokumentasi') ?>
                    </div>
                </div> -->

                <div>
                    <label for="jumlah">Jumlah</label>
                    <input type="text" name="jumlah" class="<?= form_error('jumlah') ? 'invalid' : '' ?>" placeholder="Jumlah" value="<?= set_value('jumlah') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('jumlah') ?>
                    </div>
                </div>

                <div>
                    <label for="deskripsi">Deskripsi</label>
                    <input type="text" name="deskripsi" class="<?= form_error('deskripsi') ? 'invalid' : '' ?>" placeholder="Deskripsi" value="<?= set_value('deskripsi') ?>" />
                    <div class="invalid-feedback">
                        <?= form_error('deskripsi') ?>
                    </div>
                </div>

                <div>
                    <button type="submit" class="button button-primary">Submit</button>
                    <!-- <a href="<?= base_url('admin/kas')?>" class="btn btn-success">Kembali</a> -->
                </div>

            </form>

            <?php $this->load->view('admin/_partials/footer.php') ?>
        </div>
    </main>
</body>

</html>
