<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <main class="main">
        <?php $this->load->view('admin/_partials/side_nav.php') ?>

        <div class="content">
            <h1>Edit Anggota</h1>

            <form action="" method="POST">
            <div>
                <label for="title">Nama Anggota</label>
                <input type="text" name="title" class="<?= form_error('title') ? 'invalid' : '' ?>" value="<?= form_error('title') ? set_value('title') : $anggota->title ?>" />
                <div class="invalid-feedback">
                    <?= form_error('title') ?>
                </div>
            </div>

            <!-- <div>
                    <label for="id_user">Id User</label>
                    <select name="id_user" class="<?= form_error('id_user') ? 'invalid' : '' ?>">
                        <option value="">Pilih User</option>
                        <?php foreach ($list_id_users as $user) : ?>
                            <option value="<?= $user->id_user ?>" <?= $anggota->id_user == $user->id_user ? 'selected' : '' ?>><?= $user->name ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">
                        <?= form_error('id_user') ?>
                    </div>
            </div> -->

            <div>
                <label for="divisi">Divisi</label>
                <input type="text" name="divisi" class="<?= form_error('divisi') ? 'invalid' : '' ?>" value="<?= form_error('divisi') ? set_value('divisi') : $anggota->divisi ?>" />
                <div class="invalid-feedback">
                    <?= form_error('divisi') ?>
                </div>
            </div>

            <div>
                <label for="jabatan">Jabatan</label>
                <input type="text" name="jabatan" class="<?= form_error('jabatan') ? 'invalid' : '' ?>" value="<?= form_error('jabatan') ? set_value('jabatan') : $anggota->jabatan ?>" />
                <div class="invalid-feedback">
                    <?= form_error('jabatan') ?>
                </div>
            </div>

            <div>
                <label for="content">Deskripsi</label>
                <textarea name="content" cols="30" rows="10" placeholder="Tuliskan deskripsi anda"><?= form_error('content') ? set_value('content') : $anggota->content ?></textarea>
            </div>

            <div>
                <button type="submit" class="button button-primary">Submit</button>
            </div>

            </form>

            <?php $this->load->view('admin/_partials/footer.php') ?>
        </div>
    </main>
</body>

</html>
