<?php

class Ukm_model extends CI_Model
{
    private $_table = 'anggota';

	public function get()
	{
		$query = $this->db->get($this->_table);
		return $query->result();
		// $this->db->select('anggota.id_anggota, anggota.title, anggota.divisi, anggota.jabatan, anggota.content, anggota.id_user, user.name as user_name');
		// $this->db->from('anggota');
		// $this->db->join('user', 'user.id_user = anggota.id_user', 'inner');
		
		// $query = $this->db->get();
		// return $query->result();
	}

	// public function getUsersList()
    // {
    //     $this->db->select('id_user, name'); 
    //     $query = $this->db->get('user'); 

    //     return $query->result(); 
    // }

    public function get_published()
    {
        $query = $this->db->get($this->_table);
        return $query->result();
    }

    public function get_specific_data()
    {
        $query = $this->db->get($this->_table);
        return $query->result();
    }

	public function find($id_anggota)
	{
		if (!$id_anggota) {
			return;
		}

		$query = $this->db->get_where($this->_table, array('id_anggota' => $id_anggota));
		return $query->row();
		// if (!$id_anggota) {
        //     return;
        // }

        // $this->db->select('anggota.id_anggota, anggota.title, anggota.divisi, anggota.jabatan, anggota.content, user.id_user, user.name, user.email, user.username, user.password, user.last_login');
        // $this->db->from($this->_table);
        // $this->db->join('user', 'user.id_user = anggota.id_user', 'inner');
        // $this->db->where('anggota.id_anggota', $id_anggota);

        // $query = $this->db->get();
        // return $query->row();
	}

	public function search($keyword)
	{
		if(!$keyword){
			return null;
		}
		$this->db->like('title', $keyword);
		$this->db->or_like('divisi', $keyword);
		$this->db->or_like('jabatan', $keyword);
		$this->db->or_like('content', $keyword);
		$query = $this->db->get($this->_table);
		return $query->result();
		// if (!$keyword) {
        //     return null;
        // }

        // $this->db->select('anggota.id_anggota, anggota.title, anggota.divisi, anggota.jabatan, anggota.content, user.id_user, user.name, user.email, user.username, user.password, user.last_login');
        // $this->db->from($this->_table);
        // $this->db->join('user', 'user.id_user = anggota.id_user', 'inner');
        // $this->db->like('anggota.title', $keyword);
        // $this->db->or_like('anggota.divisi', $keyword);
        // $this->db->or_like('anggota.jabatan', $keyword);
        // $this->db->or_like('anggota.content', $keyword);

        // $query = $this->db->get();
        // return $query->result();
	}

	public function insert($anggota)
	{
		return $this->db->insert($this->_table, $anggota);
	}


	public function update($anggota)
	{
		if (!isset($anggota['id_anggota'])) {
			return;
		}

		return $this->db->update($this->_table, $anggota, ['id_anggota' => $anggota['id_anggota']]);
	}

	public function delete($id_anggota)
	{
		if (!$id_anggota) {
			return;
		}

		return $this->db->delete($this->_table, ['id_anggota' => $id_anggota]);
	}

	public function count(){
		return $this->db->count_all($this->_table);
	}

	public function rules()
	{
    return [
        [
            'field' => 'title',
            'label' => 'Title',
            'rules' => 'required|max_length[255]'
        ],
        [
            'field' => 'divisi',
            'label' => 'Divisi',
            'rules' => 'required|max_length[50]' // Validasi untuk divisi
        ],
        [
            'field' => 'jabatan',
            'label' => 'Jabatan',
            'rules' => 'required|max_length[50]' // Validasi untuk jabatan
        ],
        [
            'field' => 'content',
            'label' => 'Content',
            'rules' => '' // Aturan validasi untuk content dikosongkan
		],
		// [
		// 	'field' => 'id_user',
		// 	'label' => 'Id User',
		// 	'rules' => 'required'
		// ],
    ];
}
}