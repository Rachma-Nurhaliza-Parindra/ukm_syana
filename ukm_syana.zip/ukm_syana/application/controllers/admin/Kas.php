<?php

class Kas extends CI_Controller
{
    public function __construct()
	{
        parent::__construct();
		$this->load->model('Kas_model');
		$this->load->model('auth_model');
        $this->load->model('Dokumentasi_model');
		if(!$this->auth_model->current_user()){
			redirect('auth/login');
		}
		$this->load->model('Kas_model');
	}
	
	public function index()
	{
        // $data['current_user'] = $this->auth_model->current_user();
		// $data['ukmm'] = $this->Kas_model->get();
        // $data['keyword'] = $this->input->get('keyword');
        // if(!empty($this->input->get('keyword'))){
        //     $data['ukmm'] = $this->Kas_model->search($data['keyword']);
        // }
		// if(count($data['ukmm']) <= 0 && !$this->input->get('keyword')){
		// 	$this->load->view('admin/kas_empty.php');
		// } else {
		// 	$this->load->view('admin/kas_list.php', $data);
		// }
        $data['current_user'] = $this->auth_model->current_user();
        $data['ukmm'] = $this->Kas_model->get();
        $data['keyword'] = $this->input->get('keyword');
        
        if (!empty($data['keyword'])) {
            $data['ukmm'] = $this->Kas_model->search($data['keyword']);
        }
        
        if (empty($data['ukmm']) && empty($data['keyword'])) {
            $this->load->view('admin/kas_empty.php', $data);
        } else {
            $this->load->view('admin/kas_list.php', $data);
        }
	}

    public function new()
    {
        $this->load->library('form_validation');
        $data['list_id_dokumentasi'] = $this->Kas_model->getNamaKegiatanList();
    
        if ($this->input->method() === 'post') {
            $rules = $this->Kas_model->rules();
            $this->form_validation->set_rules($rules);
            $rules = $this->Dokumentasi_model->rules();
    
            if ($this->form_validation->run() === FALSE) {
                return $this->load->view('admin/kas_new_form.php');
            }
    
            $kas = [
                'id_dokumentasi' => $this->input->post('id_dokumentasi'),
                'nama_kegiatan' => $this->input->post('nama_kegiatan'), // Ambil nama_kegiatan dari form
                'status' => $this->input->post('status'),
                'tanggal' => $this->input->post('tanggal'),
                'deskripsi' => $this->input->post('deskripsi'),
                'jumlah' => $this->input->post('jumlah')
            ];

            // $dokumentasi = [
            //     'id_dokumentasi' => $this->input->post('id_dokumentasi'),
            //     'nama_kegiatan' => $this->input->post('nama_kegiatan'),
            // ];
        
            $saved = $this->Kas_model->insert($kas);

            if ($saved) {
                $this->session->set_flashdata('message', 'Data was created');
                return redirect('admin/kas');
            }
        }

        $this->load->view('admin/kas_new_form.php');
    }

    public function edit($id_kas = null)
    {
        // $data['kas'] = $this->Kas_model->find($id_kas);
        // $data['list_id_dokumentasi'] = $this->Kas_model->getNamaKegiatanList();
        
        // // Mengambil data nama kegiatan dari tabel dokumentasi
        // $data['dokumentasi'] = $this->Kas_model->find($id_kas);
    
        // $this->load->library('form_validation');
    
        // if (!$data['kas'] || !$id_kas) {
        //     show_404();
        // }
    
        // if ($this->input->method() === 'post') {
        //     $rules = $this->Kas_model->rules();
        //     $this->form_validation->set_rules($rules);
    
        //     if ($this->form_validation->run() === FALSE) {
        //         return $this->load->view('admin/kas_edit_form.php', $data);
        //     }
    
        //     $kas = [
        //         'id_dokumentasi' => $this->input->post('id_dokumentasi'),
        //         'status' => $this->input->post('status'),
        //         'tanggal' => $this->input->post('tanggal'),
        //         'deskripsi' => $this->input->post('deskripsi'),
        //         'jumlah' => $this->input->post('jumlah')
        //     ];

        $data['kas'] = $this->Kas_model->find($id_kas);
        $data['list_id_dokumentasi'] = $this->Kas_model->getNamaKegiatanList();
        $data['dokumentasi'] = $this->Kas_model->find($id_kas); // Mengambil data nama kegiatan dari tabel dokumentasi
    
        $this->load->library('form_validation');
    
        if (!$data['kas'] || !$id_kas) {
            show_404();
        }
    
        if ($this->input->method() === 'post') {
            $rules = $this->Kas_model->rules();
            $this->form_validation->set_rules($rules);
    
            if ($this->form_validation->run() === FALSE) {
                return $this->load->view('admin/kas_edit_form.php', $data);
            }
    
            $kas = [
                'id_kas' => $id_kas,
                'id_dokumentasi' => $this->input->post('id_dokumentasi'),
                'nama_kegiatan' => $this->input->post('nama_kegiatan'), // Ambil nama_kegiatan dari form
                'status' => $this->input->post('status'),
                'tanggal' => $this->input->post('tanggal'),
                'deskripsi' => $this->input->post('deskripsi'),
                'jumlah' => $this->input->post('jumlah')
            ];


            // $dokumentasi = [
            //     'nama_kegiatan' => $this->input->post('nama_kegiatan'),
            // ];

            $updated = $this->Kas_model->update($kas);

            if ($updated) {
                $this->session->set_flashdata('message', 'Data berhasil diperbarui');
                redirect('admin/kas');
            }
        }
    
        $this->load->view('admin/kas_edit_form.php', $data);
    }

    public function delete($id_kas = null)
    {
        if (!$id_kas) {
            show_404();
        }

        $deleted = $this->Kas_model->delete($id_kas);
        if ($deleted) {
            $this->session->set_flashdata('message', 'Data was deleted');
            redirect('admin/kas');
        }
    }

    public function getTotalUang()
    {
        $total_uang = $this->Kas_model->get_total_uang();
        return $total_uang;
    }

    public function showTotalUang()
    {
        $total_uang = $this->getTotalUang();
        echo "Total Uang: " . $total_uang;
    }
}