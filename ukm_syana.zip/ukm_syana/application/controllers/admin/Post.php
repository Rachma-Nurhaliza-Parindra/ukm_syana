<?php

class Post extends CI_Controller
{

    public function __construct()
	{
        parent::__construct();
		$this->load->model('Ukm_model');
		$this->load->model('auth_model');
		if(!$this->auth_model->current_user()){
			redirect('auth/login');
		}
		$this->load->model('Ukm_model');
	}
	public function index()
	{
        $data['current_user'] = $this->auth_model->current_user();
		$data['ukmm'] = $this->Ukm_model->get();
        $data['keyword'] = $this->input->get('keyword');
        if(!empty($this->input->get('keyword'))){
            $data['ukmm'] = $this->Ukm_model->search($data['keyword']);
        }
        if(count($data['ukmm']) <= 0 && !$this->input->get('keyword')){
            $this->load->view('admin/post_empty.php', $data);
        } else {
            $this->load->view('admin/post_list.php', $data);
        }
	}

    public function new()
    {
        $this->load->library('form_validation');
        if ($this->input->method() === 'post') {
            // TODO: Lakukan validasi sebelum menyimpan ke model

            // Lakukan validasi sebelum menyimpan ke model
			$rules = $this->Ukm_model->rules();
			$this->form_validation->set_rules($rules);

			if($this->form_validation->run() === FALSE){
				return $this->load->view('admin/post_new_form.php');
			}

            $anggota = [
                'title' => $this->input->post('title'),
                'divisi' => $this->input->post('divisi'),
                'jabatan' => $this->input->post('jabatan'),
                'content' => $this->input->post('content')
            ];
        
            $saved = $this->Ukm_model->insert($anggota);
        
            if ($saved) {
                $this->session->set_flashdata('message', 'Data was created');
                return redirect('admin/post');
            }
        }
        
        $this->load->view('admin/post_new_form.php');
        
    }
    public function edit($id_anggota = null)
{
    $data['anggota'] = $this->Ukm_model->find($id_anggota);
    $this->load->library('form_validation');

    if (!$data['anggota'] || !$id_anggota) {
        show_404();
    }

    if ($this->input->method() === 'post') {
        	// lakukan validasi data seblum simpan ke model
			$rules = $this->Ukm_model->rules();
			$this->form_validation->set_rules($rules);

			if($this->form_validation->run() === FALSE){
				return $this->load->view('admin/post_edit_form.php', $data );
			}
        // TODO: Lakukan validasi sebelum menyimpan ke model
        $anggota = [
            'id_anggota' => $id_anggota,
            'title' => $this->input->post('title'),
            'divisi' => $this->input->post('divisi'),
            'jabatan' => $this->input->post('jabatan'),
            'content' => $this->input->post('content')
        ];
        $updated = $this->Ukm_model->update($anggota);
        if ($updated) {
            $this->session->set_flashdata('message', 'Data was updated');
            redirect('admin/post');
        }
    }

    $this->load->view('admin/post_edit_form.php', $data);
}
    public function delete($id_anggota = null)
    {
    if (!$id_anggota) {
        show_404();
    }

    $deleted = $this->Ukm_model->delete($id_anggota);
    if ($deleted) {
        $this->session->set_flashdata('message', 'Data was deleted');
        redirect('admin/post');
    }
}
}


// class Post extends CI_Controller
// {

//     public function __construct()
// 	{
//         parent::__construct();
// 		$this->load->model('Ukm_model');
// 		$this->load->model('auth_model');
// 		if (!$this->auth_model->current_user()) {
// 			redirect('auth/login');
// 		}
// 		$this->load->model('Ukm_model');
// 	}

// 	public function index()
// 	{
// 		$data['current_user'] = $this->auth_model->current_user();
//         $data['ukmm'] = $this->Ukm_model->get();
//         $data['keyword'] = $this->input->get('keyword');
//         if (!empty($data['keyword'])) {
//             $data['ukmm'] = $this->Ukm_model->search($data['keyword']);
//         }
//         if (empty($data['ukmm']) && !$data['keyword']) {
//             $this->load->view('admin/post_empty.php', $data);
//         } else {
//             $this->load->view('admin/post_list.php', $data);
//         }
// 	}

// 	public function newPost()
// 	{
// 		$this->load->library('form_validation');
// 		$data['list_id_users'] = $this->Ukm_model->getUsersList();

// 		if ($this->input->method() === 'post') {
// 			$rules = $this->Ukm_model->rules();
// 			$this->form_validation->set_rules($rules);

// 			if ($this->form_validation->run() === FALSE) {
// 				return $this->load->view('admin/post_new_form.php');
// 			}

// 			$anggota = [
// 				'id_user' => $this->input->post('id_user'), // Menambahkan input id_user
// 				'title' => $this->input->post('title'),
// 				'divisi' => $this->input->post('divisi'),
// 				'jabatan' => $this->input->post('jabatan'),
// 				'content' => $this->input->post('content')
// 			];

// 			$saved = $this->Ukm_model->insert($anggota);

// 			if ($saved) {
// 				$this->session->set_flashdata('message', 'Data was created');
// 				return redirect('admin/post');
// 			}
// 		}

// 		$this->load->view('admin/post_new_form.php');
// 	}

// 	public function edit($id_anggota = null)
// 	{
// 		$data['anggota'] = $this->Ukm_model->find($id_anggota);
// 		$data['list_id_users'] = $this->Ukm_model->getUsersList();

// 		$this->load->library('form_validation');
// 		if (!$data['anggota'] || !$id_anggota) {
// 			show_404();
// 		}

// 		if ($this->input->method() === 'post') {
// 			$rules = $this->Ukm_model->rules();
// 			$this->form_validation->set_rules($rules);

// 			if ($this->form_validation->run() === FALSE) {
// 				return $this->load->view('admin/post_edit_form.php', $data);
// 			}

// 			$anggota = [
// 				'id_anggota' => $id_anggota,
// 				'id_user' => $this->input->post('id_user'), // Menambahkan input id_user
// 				'title' => $this->input->post('title'),
// 				'divisi' => $this->input->post('divisi'),
// 				'jabatan' => $this->input->post('jabatan'),
// 				'content' => $this->input->post('content')
// 			];

// 			$updated = $this->Ukm_model->update($anggota);
// 			if ($updated) {
// 				$this->session->set_flashdata('message', 'Data was updated');
// 				redirect('admin/post');
// 			}
// 		}

// 		$this->load->view('admin/post_edit_form.php', $data);
// 	}

// 	public function delete($id_anggota = null)
// 	{
// 		if (!$id_anggota) {
// 			show_404();
// 		}

// 		$deleted = $this->Ukm_model->delete($id_anggota);
// 		if ($deleted) {
// 			$this->session->set_flashdata('message', 'Data was deleted');
// 			redirect('admin/post');
// 		}
// 	}
// }

